#include <stdio.h>
#include <stdlib.h>

//Fun��o principal do programa
void main(){

    //Definindo Vari�veis
    char letra = 'x';

    //Condicional Simples
    if(letra == 'x'){
        printf("\nA letra eh x.");
    }

    //C�digo em ASCII
    printf("\nCodigo da letra = %d", letra);

    //Comparando C�digo ASCII
    if(letra == 120){
         printf("\n A letra eh x.");
    }

    //Pausa o programa ap�s executar
    system("pause");

}

